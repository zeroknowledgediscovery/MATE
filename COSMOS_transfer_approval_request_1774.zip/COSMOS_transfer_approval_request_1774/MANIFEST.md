# COSMOS export approval package — Request #1774

This archive collects the evidence and exported files associated with the Epic COSMOS file transfer approval used for the MATE / ReTransplant work.

## Transfer metadata

- **Request number:** 1774
- **Cosmos project:** D737CE1
- **Organization:** UK HealthCare
- **Movement:** Out of the Cosmos DSVM
- **COSMOS export location:** `Z:\Project D737CE1\EXPORT`
- **Request received:** September 3, 2026
- **Epic review completed:** September 10, 2026
- **Epic reviewer:** Kenneth Fisher, Quality Management | Cosmos
- **Dmytro confirmation:** November 11, 2026 — confirmed approval for export of ReTransplant summary statistics for publication
- **Latest forwarded evidence email:** November 19, 2026

## Included evidence

`COSMOS_TRANSFER_APPROVAL.txt` records the relevant text from the approval thread and the Gmail message/thread identifiers used to retrieve it.

## Exported files

The `exported_files/` directory contains the six CSVs Epic attached after completion of the file-transfer review.

## Integrity

SHA-256 checksums are provided in `SHA256SUMS.txt`.
